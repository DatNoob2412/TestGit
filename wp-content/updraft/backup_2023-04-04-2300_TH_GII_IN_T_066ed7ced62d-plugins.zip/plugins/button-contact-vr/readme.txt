=== Button contact VR ===
Contributors: VirusTran
Tags: Button contact call, zalo, whatsapp, messenger, popup, showroom
Donate link: paypal.me/virustran
Requires at least: 5.0
Tested up to: 6.1
Requires PHP: 5.6
License: 4.1.1
Developer: https://github.com/virustran/button-contact-vr/tree/develops
License URI: http://www.gnu.org/licenses/gpl.html

Button contact VR

== Description ==

Fixed Hotline, zalo, viber, contact, whatsapp, messenger, popup form, popup showroom...
Location left - right - bottom
Size scale
All in one
Popup form (title, content, form, image and location)

=== From within WordPress ===

1. Visit 'Plugins > Add New'
2. Search for 'Button contact VR'
3. Activate Button contact VR from your Plugins page.

=== Manually ===

1. Upload the 'Button contact VR' folder to the '/wp-content/plugins/' directory
2. Activate the Hotline Phone Ring plugin through the 'Plugins' menu in WordPress
3. Go to "after activation" below.

== Installation ==
1. Visit \Plugins > Add New
2. Search for \Button contact VR\
3. Activate Button contact VR from your Plugins page.

== Help ==
https://webvocuc.com/blog/tag/button-contact-vr
https://github.com/virustran/button-contact-vr/tree/develops

== Screenshots ==
1. Visit Plugins > Search for Button contact VR
2. Fill in the information > save
3. Advanced settings - Size scale - hide on desktop or mobile
4. Congratulations!

== Changelog ==

= 1.0 =
* First release.

= 1.1 =
* Release Date - 07/05/2020.
* Fix - link viber.

= 2.0 =
* Release Date - 16/07/2020.
* Add Advanced settings
* Size scale
* Location left - right - bottom
* Hide on mobile or desktop

= 2.1 =
* Release Date - 29/07/2020.
* Fix hotline bar
* Add menu Advanced settings

= 3.0 =
* Release Date - 07/07/2021.
* Add menu All in one

= 4.0 =
* Release Date - 08/06/2022.
* Add Whatsapp
* Add Showroom
* Add Contact form (beta)
* Add css and js

= 4.1 =
* Fix showroom and contact

= 4.2 =
* Add action links
* Update Tested up to