<?php
namespace ivole\Firebase\JWT;

class ExpiredException extends \UnexpectedValueException
{

}
